package com.session.springsession.domain.user;

public class SecurityConstants {
    public static String KEY_ROLE = "role";
}
