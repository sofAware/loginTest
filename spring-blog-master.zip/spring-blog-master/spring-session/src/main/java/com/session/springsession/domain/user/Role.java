package com.session.springsession.domain.user;

public enum Role {
    // 권한 추가
    ADMIN, USER
}
