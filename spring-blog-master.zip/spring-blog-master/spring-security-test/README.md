# spring-security-test
spring security를 활용하여 간단한 로그인, 회원가입, 유저페이지, 관리자 페이지를 만들어본 소규모 프로젝트입니다.   

공부한 내용과 코드에 대한 설명은 [블로그](https://imgzon.tistory.com/101) 에 올려두었습니다.