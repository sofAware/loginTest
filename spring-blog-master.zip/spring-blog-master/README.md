# spring-blog
spring, spring boot 공부 시 소규모 프로젝트들을 올리는 공간입니다. 공부한 내용은 [블로그](https://imgzon.tistory.com/) 에 올릴 것입니다.

- [spring-security-test](https://imgzon.tistory.com/101) : spring security 이용한 로그인/회원가입 구현
- spring-session : session 기능 활용한 인증, 인가 구현