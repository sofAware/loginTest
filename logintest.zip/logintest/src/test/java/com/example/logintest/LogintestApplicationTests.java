package com.example.logintest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogintestApplicationTests {

	@Test
	void contextLoads() {
	}

}
